package com.example.util;

import com.hazelcast.core.*;
import com.hazelcast.map.IMap;
import com.hazelcast.topic.ITopic;
import com.hazelcast.topic.MessageListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class DistributedCacheUtil {

    private final HazelcastInstance hazelcastInstance;

    @Autowired
    public DistributedCacheUtil(HazelcastInstance hazelcastInstance) {
        this.hazelcastInstance = hazelcastInstance;
    }

    private static final String CACHE_NAME = "app-distributed-cache";

    public void put(String key, Object value, long ttlSeconds) {
        IMap<String, Object> map = hazelcastInstance.getMap(CACHE_NAME);
        map.put(key, value, ttlSeconds, TimeUnit.SECONDS);
    }

    public Object get(String key) {
        IMap<String, Object> map = hazelcastInstance.getMap(CACHE_NAME);
        return map.get(key);
    }

    public void remove(String key) {
        IMap<String, Object> map = hazelcastInstance.getMap(CACHE_NAME);
        map.remove(key);
    }

    public void publish(String topicName, String message) {
        ITopic<String> topic = hazelcastInstance.getTopic(topicName);
        topic.publish(message);
    }

    public void subscribe(String topicName, MessageListener<String> listener) {
        ITopic<String> topic = hazelcastInstance.getTopic(topicName);
        topic.addMessageListener(listener);
    }
}
