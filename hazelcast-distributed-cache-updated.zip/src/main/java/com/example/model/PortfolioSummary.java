package com.example.model;

import java.io.Serializable;

public class PortfolioSummary implements Serializable {
    private String userId;
    private String summary;

    public PortfolioSummary() {
    }

    public PortfolioSummary(String userId, String summary) {
        this.userId = userId;
        this.summary = summary;
    }

    public String getUserId() {
        return userId;
    }

    public String getSummary() {
        return summary;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }
}
