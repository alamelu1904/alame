package com.example.util;

import com.example.model.PortfolioSummary;
import org.springframework.stereotype.Component;

@Component
public class ExternalApiClient {

    public PortfolioSummary fetchPortfolio(String userId) {
        // Simulate data aggregation
        return new PortfolioSummary(userId, "Equity: 60%, Bonds: 30%, Gold: 10%");
    }
}
