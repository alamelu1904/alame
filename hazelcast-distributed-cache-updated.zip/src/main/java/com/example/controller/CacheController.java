package com.example.controller;

import com.example.util.DistributedCacheUtil;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cache")
public class CacheController {

    @Autowired
    private DistributedCacheUtil cacheUtil;

    @PostConstruct
    public void setupSubscription() {
        cacheUtil.subscribe("my-topic", message -> {
            System.out.println("Received from topic: " + message.getMessageObject());
        });
    }

    @PostMapping("/put")
    public ResponseEntity<?> put(@RequestParam String key, @RequestParam String value) {
        cacheUtil.put(key, value, 300);
        return ResponseEntity.ok("Cached");
    }

    @GetMapping("/get")
    public ResponseEntity<?> get(@RequestParam String key) {
        return ResponseEntity.ok(cacheUtil.get(key));
    }

    @PostMapping("/publish")
    public ResponseEntity<?> publish(@RequestParam String msg) {
        cacheUtil.publish("my-topic", msg);
        return ResponseEntity.ok("Published");
    }
}
