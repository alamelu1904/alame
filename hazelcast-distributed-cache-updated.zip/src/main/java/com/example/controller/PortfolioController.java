package com.example.controller;

import com.example.model.PortfolioSummary;
import com.example.service.PortfolioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/portfolio")
public class PortfolioController {

    @Autowired
    private PortfolioService portfolioService;

    @GetMapping("/{userId}")
    public ResponseEntity<?> getPortfolio(@PathVariable String userId) {
        PortfolioSummary summary = portfolioService.getPortfolio(userId);
        return ResponseEntity.ok(summary);
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<?> invalidatePortfolio(@PathVariable String userId) {
        portfolioService.invalidatePortfolio(userId);
        return ResponseEntity.ok("Cache invalidated");
    }
}
