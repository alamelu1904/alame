package com.example.service;

import com.example.model.PortfolioSummary;
import com.example.util.ExternalApiClient;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class PortfolioService {

    @Autowired
    private HazelcastInstance hazelcastInstance;

    @Autowired
    private ExternalApiClient apiClient;

    private static final String CACHE_NAME = "portfolio-cache";

    public PortfolioSummary getPortfolio(String userId) {
        IMap<String, PortfolioSummary> cache = hazelcastInstance.getMap(CACHE_NAME);
        String key = "user:" + userId;

        PortfolioSummary cached = cache.get(key);
        if (cached != null) {
            return cached;
        }

        PortfolioSummary fresh = apiClient.fetchPortfolio(userId);
        cache.put(key, fresh, 5, TimeUnit.MINUTES);
        return fresh;
    }

    public void invalidatePortfolio(String userId) {
        hazelcastInstance.getMap(CACHE_NAME).remove("user:" + userId);
    }
}
